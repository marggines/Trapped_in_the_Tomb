@echo off
start "" "FS-UAE\Windows\x86-64\fs-uae.exe" --config FS-UAE\Configurations\Trapped_in_the_Tomb.fs-uae
exit